<?php  

$mysqli= @new mysqli("localhost", "root","","idb_bisew");



?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Student</title>
</head>





<body >
<?php 


$query= "select * from student";
$result= mysqli_query($mysqli,$query);

 ?>
					<table border="1">
						<tr>
							<td> ID</td>
							<td> Name</td>
							<td>Address</td>
							<td>Mobile</td>
							<td>Edit</td>
							<td>Delete</td>
						</tr>

						<?php

						while($row= mysqli_fetch_assoc($result)){
							$id=$row['id'];
							$name=$row['name'];
							$address=$row['address'];
							$mobile=$row['mobile'];
						?>
						<tr>
							<td><?php echo $id ?></td>
							<td><?php echo $name ?></td>
							<td><?php echo $address ?></td>
							<td><?php echo $mobile ?></td>
							<td><a href="s_edit.php?GetID=<?php echo $user_id ?>">Edit</a></td>
							<td><a href="delete.php?Del=<?php echo $user_id ?>">Delete</a></td>
						</tr>
						<?php  

					}

						?>

					</table>
				</div>
			</div>
		</div>
	</div>