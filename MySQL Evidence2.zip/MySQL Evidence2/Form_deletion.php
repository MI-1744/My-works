<?php 

$mysqli= @new mysqli("localhost", "root","","idb_bisew");

 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Form Delete</title>
</head>
<body>
    <h2>Delete from student Table</h2>
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
    <select name="id">
        
<option value="" hidden="">---Select One---</option>
<option value="">
<?php 

    
$sql="SELECT * FROM student ";
$res= $mysqli->query($sql);
while($x=$res->fetch_assoc()){?>

<option value="<?php echo $x['id'] ?>">
    <?php echo $x['name'] ?>
</option>
<?php }?>


</option>
</select>
    <br>
    <br>
    <br>
    <input type="submit" name="submit" value="Delete">
</form>
<?php 

if(isset($_POST['submit'])){
extract($_POST);
$sql="DELETE FROM student WHERE id='$id'";
$mysqli->query($sql);
if($mysqli->affected_rows){
    echo "Deleted succesfully";
}



}





 ?>
</body>
</html>