<?php 

$mysqli= @new mysqli("localhost", "root","","idb_bisew");

 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login Form</title>
</head>
<body>
	<form action="" method="post">
		<input type="email" name="email" placeholder="Email">
		<br>
		<input type="password" name="pass" placeholder="Password">
		<br>
		<input type="submit" name="submit" value="Login">
	</form>
	<?php 

if(isset($_POST['submit'])){

extract($_POST);
$query="SELECT * from user2 WHERE email='$email' AND password='$pass'";

$res= $mysqli->query($query);
if($res->num_rows==1){

echo "Your mail is validated";
}else{
	echo "Mail/Password is invalid";
}




}









	 ?>

</body>
</html>