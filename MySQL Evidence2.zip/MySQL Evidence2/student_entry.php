<?php 

$mysqli= @new mysqli("localhost", "root","","idb_bisew");

 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Entry Form</title>
</head>
<body>
<form action="" method="post">
    <input type="text" name="name" placeholder="Enter Name">
    <br>
    <textarea name="address"></textarea>
    <br>
    <input type="text" name="mobile" placeholder="Enter Mobile Number">
    <br>
    <input type="submit" name="submit" value="Enter">
</form>

<?php 
if(isset($_POST['submit'])){


extract($_POST);
$sql="CALL inser_in_student_table('$name','$address','$mobile')";
$mysqli->query($sql);
if($mysqli->affected_rows){

    echo "Data Entry Successful";
}
}
?>
</body>
</html>