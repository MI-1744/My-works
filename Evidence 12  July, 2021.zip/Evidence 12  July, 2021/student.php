
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width =device-width, initial-scale=1.0">
	<title>Student Information</title>
	<style >
		.form{
		background-color: lightgray;
		width: 300px;
		padding: 20px;
		border: 2px solid black;
	}
	</style>
</head>
<body>

<form action="" class="form">
	<h2>Students' Information</h2>
 	<select name="stid" id="">
 		<option value="" hidden="">---Select One---</option>
 		<option value="101">101</option>
 		<option value="102">102</option>
 		<option value="103">103</option>
 		<option value="104">104</option>
 		<option value="105">105</option>
 	</select>
 	<br>
 	<br>
 
 	<input type="submit" name="submit" value="SHOW RESULT">
 	<br>
 	<br>
 	<br>
 </form>





 <?php 

	class Student{
		
		private $data;

		public function __construct($file){
				
			$data = file($file);
			$this->data = $data;
			return $this->data;
		}

		public function result($stid){
			echo "<table>";


			foreach($this->data as $item){
		list($id, $name, $batch) = explode(",", $item);
			if($id == $stid){
				echo "<tr><th>ID: </th><td>$id</td></tr> <tr><th>Name:</th><td>$name</td></tr><tr><th>Batch:</th><td>$batch</td></tr>";



			// echo "ID: ".$id ."<br>". "Name: ".$name."<br>"."Batch:". $batch."<br>";
			break;
				}
			}
			echo "</table>";
		}
	}
	
	$stobj = new Student("Result.txt");
	


 if(isset($_GET['submit'])){
 	$id = $_GET['stid'];
 	$stobj->result($id);
 }
  ?>

</body>
</html>