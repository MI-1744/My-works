<?php  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width =device-width, initial-scale=1.0">
	<title>Students' Data</title>
</head>
<body>
<form method="post">
	<select name="sid">
		<option value=""></option>
		<option value="101">101</option>
		<option value="102">102</option>
		<option value="103">103</option>
		<option value="104">104</option>
		<option value="105">105</option>
	</select>
	<input type="submit" name="submit" value="Check">
</form>


<?php 
class Student{

	public $data;
	public function __construct($file){
		$data= file($file);
		$this->data=$data;
		return $this->data;
	}

public function result($sid){
	foreach ($this->data as $key ) {

		list($id, $name, $batch)=explode(",", $key);
		if($id== $sid){
			echo "ID Number: $id<br>Name: $name <br> Batch: $batch";

}

}}
}
$sobj=new Student("Result.txt");

if(isset($_POST['submit'])){
	$id= $_POST['sid'];
	$sobj->result($id);
}




 ?>

</body>
</html>