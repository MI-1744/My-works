<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width =device-width, initial-scale=1.0">
	<title>Login Form</title>

<style >
	.gr{
		
	
		color: green;
	}
	.red{
		
		
		
		color: red;

	}
	.form{
		background-color: lightblue;
		width: 300px;
		padding: 20px;
		border: 2px solid black;
	}
</style>


</head>
<body>



<form class="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
	
<table>
	<h2>Login Form</h2>
	<tr>
		<th>User name</th>
		<td><input type="text" name="name"></td>
	</tr>
	<tr>
		<th>Email</th>
		<td><input type="text" name="mail"></td>
	</tr>
	
	<tr>
		<th></th>
		<td>
			<input type="submit" name="submit" value="Submit">
			<input type="reset" value="Reset" name="">
		</td>
	</tr>
</table>

</form>



<?php 

if(isset($_POST['submit'])){


       $n= $_POST['name'];
       $e= $_POST['mail'];

if(strlen($n)>=4 && strlen($n)<=8){
	echo "<div class='gr'><h3>Your User Name is correct</h3></div>";
}else{
	echo "<div class='red'><h3>User name Must be more than 4 and less than 8 Character</h3></div>";
}

if(filter_var($e, FILTER_VALIDATE_EMAIL)==true){

	echo "<div class='gr'><h3>Your Email is validated</h3></div>";
}else{
	echo "<div class='red'><h3>Enter a valid Email Address</h3><br></div>";
}




}


 ?>




</body>
</html>