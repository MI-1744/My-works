<?php 

$x= 
$x[]=array(
array( "ID"=>"1","Name"=>"Mynul", "mcq"=>"40", "des"=>"37", "evi"=>"30"),

$x[]= array( "ID"=>"2", "Name"=>"Siam", "mcq"=>"38", "des"=>"40", "evi"=>"40")

);
?>


<table border="1">
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>MCQ</th>
		<th>Descriptive</th>
		<th>Evidance</th>
		<th>Status</th>
	</tr>

<?php
  foreach ($x as $key ) {
 extract($key);?>




<tr> <td><?php echo $ID ?></td>
 <td><?php echo $Name ?></td>
 <td><?php echo $mcq ?></td>
 <td><?php echo $des ?></td>
 <td><?php echo $evi ?></td>


<?php  $mcq_des=(int)$mcq+ (int)$des;
 if($mcq_des>=70 && $evi>=30){ ?>
 	<td><?php echo "Pass"; ?></td>
<?php  }else{ ?>
 	<td><?php echo "Fail"; ?></td> </tr>
<?php }

  }

 ?>
 </table> 