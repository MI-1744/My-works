<?php  ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>DOcument</title>
</head>
<body>
<form method="post">
	<h2>Show Odd and Even number between two geven Number</h2>
	<input type="text" name="fn" placeholder="Enter First Number">
	<br>
	<br>
	<input type="text" name="sn" placeholder="Enter Last Number">
	<br>
	<br>
	<input type="submit" name="submit" value="Show Odd/Even">
</form>
<?php 
if(isset($_POST['submit'])){
extract($_POST);

echo "<h3>Odd & Even Number between $fn and $sn is :</h3>";
for ($i=$fn; $i<=$sn  ; $i++) { 
	if($i%2==0){
		echo "$i is Even Number<br>";
	}else{
		echo "$i is Odd number<br>";
	}
}


}


 ?>
</body>
</html>