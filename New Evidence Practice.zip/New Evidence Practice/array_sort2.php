<?php 


$x=array('Bangladesh'=>'Dhaka','India'=>'Delhi','Pakistan'=>'Islamabad','UK'=>'London');
$y= array_flip($x);
 ksort($y);





 echo "<table border='1'> <tr><th>Capital</th><th>Country</th></tr>";
foreach($y as $key => $value){
	


echo "<tr><td>$key </td> <td>$value</td></tr>";




}








 ?>