<?php 

$x=array('Bangladesh'=>'Dhaka','USA'=>'Washington DC','UK'=>'London','Denmark'=>'Copenhegen','Canada'=>'Otoa');
$y= array_search('Otoa', $x);


print_r($y);
 ?>