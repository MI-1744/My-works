<?php  ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Students' Information</title>
</head>
<body>
<form action="">
	<table>
		<tr>
			<th>Id</th>
			<td>
				<select name="sid">
					<option value="" hidden="">---Select One---</option>
					<option value="101">101</option>
					<option value="102">102</option>
					<option value="103">103</option>
					<option value="104">104</option>
					<option value="105">105</option>

				</select>

			</td>
		</tr>
	<tr>
		<td></td>
		<td>	<input type="submit" name="submit" value="Submit"></td>
	</tr>
	</table>
</form>

<?php 

class Student{

private $data;
public function __construct($file){

$data= file($file);
$this->data=$data;
return $this->data;
}
public function result($sid){
	foreach($this->data as $items){
		list($id,$name,$mail,$number)=explode(",", $items);
		if($id==$sid){
            echo "$id<br>";
			echo "$name<br>";
			echo "$mail<br>";
			echo "$number<br>";
		}
	}
}
}


$obs=new Student("info.txt");

if(isset($_GET['submit'])){

$id= $_GET['sid'];
$obs-> result($id);




}
 ?>
</body>
</html>