
<style t>
	#ev{
		background-color: #68decc;
		font-weight: bold;
		width: 190px;
		margin: 5px;
		text-align: center;
	}

	#odd{
		background-color: #e8e858;
		font-weight: bold;
		width: 190px;
		margin: 5px;
		text-align: center;
	}
</style>



<h2>Odd/Even Checker</h2>
<form method="post" action="">
	<p><input type="text" name="sn" placeholder="Starting Number"></p>
	<p><input type="text" name="en" placeholder="Ending Number"></p>
	<input type="submit" name="submit" value="Odd/Even Numbers">
	
</form>
<?php
	if(isset($_POST['submit'])) {
	
	$n1 = $_POST['sn'];
	$n2 = $_POST['en'];

	for($i = $n1; $i<=$n2; $i++) {
		
		if ($i%2==0) {
			echo "<div id='ev'> $i is the number even </div>"; 
		}
		else {
			echo "<div id='odd'> $i is the number odd </div>"; 
		}			
	}	
}	
?>