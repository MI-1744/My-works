<?php 



$x=array(12,9,89);
echo "<pre>";
print_r($x);
echo "</pre>";
echo "<br>";

$y= max($x);

echo "Maximum number in this array is: ".$y;



 ?>