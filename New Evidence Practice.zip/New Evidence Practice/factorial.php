
<form method="post">
	<h2>Factorial Number Checker</h2> 
	<input type="text" name="num">&nbsp;&nbsp;
	<input type="submit" name="submit" value="submit">
	
</form>
<?php
	
	if(isset($_POST['submit'])){  
		extract($_POST);
$factorial = 1; 
if(empty($num)){
	echo "Enter a number";
}else {

for ($x=$num; $x>=1; $x--)   
{  
  $factorial = $factorial * $x;  
}  
echo "<h3>Factorial of $num is $factorial</h3>"; 

}


}



?>