<?php 



$myfile= fopen("myfile.txt", "w") or die("unable to open file");
$mytext="Arif: arif@gmail.com <br>\n";
fwrite($myfile,$mytext);
$mytext="Akib: aki@gmail.com <br>\n";

fwrite($myfile,$mytext);

$myfiles= fopen("myfile.txt", "r") ;
$data=fread($myfiles, filesize("myfile.txt"));
fclose($myfile);
echo $data;








 ?>