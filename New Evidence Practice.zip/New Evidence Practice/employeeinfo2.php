

<table border="1"><tr>
	<th>ID</th>
	<th>Name</th>
	<th>Salary</th>
</tr>

<?php 

extract($_POST);
$salary= $basic+$hrent+$transport;
//echo "<h2>Salary </h2>";
echo "<tr><td> $id</td>";
echo "<td> $name</td>";
echo "<td> $salary</td></tr>";




 ?></table>
