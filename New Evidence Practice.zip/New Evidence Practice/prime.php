
<style >
        .form{
        background-color: lightcoral;
        width: 300px;
        padding: 20px;
        border: 2px solid black;
    }
    </style>

<form class="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
    
<table>
    <h2>Prime Number Checker with PHP</h2>
    <tr>
        <th>Number</th>
        <td><input type="text" name="num"></td>
    </tr>
    
    
    <tr>
        <th></th>
        <td>
            <input type="submit" name="submit" value="Check">
            <input type="reset" value="Reset" name="">
        </td>
    </tr>
</table>

</form>


<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
extract($_POST);
function check_prime($num)
{
   if ($num == 1)
   return 0;
   for ($i = 2; $i <= $num/2; $i++)
   {
      if ($num % $i == 0)
      return 0;
   }
   return 1;
}

$flag_val = check_prime($num);
if ($flag_val == 1){
   echo "<h3>$num  is a prime number</h3>";
}
else{
   echo "<h3>$num is a non-prime number</h3>";
}
}
?>