<?php  
require_once("connection.php");
if(isset($_GET['Del'])){
	$UserID= $_GET['Del'];
	$query= "delete from records where User_ID='".$UserID."'";
	$result= mysqli_query($mysqli, $query);

	if($result){
		header("location:view.php");
	} else {
		echo "Please check your query";
	}
} else {
	header("location:view.php");
}



?>