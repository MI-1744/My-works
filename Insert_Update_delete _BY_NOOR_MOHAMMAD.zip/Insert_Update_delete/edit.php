<?php 
require_once("connection.php");
$user_id=$_GET['GetID'];
$query= "select * from records where User_ID='".$user_id."'";
$result= mysqli_query($mysqli,$query);
while($row=mysqli_fetch_assoc($result)){
	$user_id=$row['User_ID'];
	$user_name=$row['User_Name'];
	$user_email=$row['User_Email'];
	$user_age=$row['User_Age'];
}

 ?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body class="bg-dark">

	<div class="container">
		<div class="row">
			<div class="col-md-6 m-auto">
				<div class="card mt-5">
					<div class="card-title">
						<h3 class="bg-success text-white text-center py-3">Update form in php</h3>
					</div>
					<div class="card-body">
						<form action="update.php?ID=<?php  echo $user_id ?>" method="post">
							<input type="text" class="form-control mb-2" placeholder="user name" name="name" value="<?php echo $user_name ?>">
							<input type="email" class="form-control mb-2" placeholder="user mail" name="mail" value="<?php echo $user_email ?>">
							<input type="text" class="form-control mb-2" placeholder="user age" name="age" value="<?php echo $user_age ?>">
							<input type="submit" class="btn btn-primary" name="update" value="UPDATE">
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>