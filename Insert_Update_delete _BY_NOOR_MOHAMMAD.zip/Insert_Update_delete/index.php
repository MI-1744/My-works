<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body class="bg-dark">

	<div class="container">
		<div class="row">
			<div class="col-md-6 m-auto">
				<div class="card mt-5">
					<div class="card-title">
						<h3 class="bg-success text-white text-center py-3">Regitration form in php</h3>
					</div>
					<div class="card-body">
						<form action="insert.php" method="post">
							<input type="text" class="form-control mb-2" placeholder="user name" name="name">
							<input type="email" class="form-control mb-2" placeholder="user mail" name="mail">
							<input type="text" class="form-control mb-2" placeholder="user age" name="age">
							<input type="submit" class="btn btn-primary" name="submit">
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>