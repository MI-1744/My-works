<?php  
$mysqli= @new mysqli("localhost", "root", "", "Crud");

if(!$mysqli){
	die('Connection error');
}
?>