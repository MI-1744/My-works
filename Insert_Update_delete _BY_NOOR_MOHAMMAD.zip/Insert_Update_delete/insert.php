<?php  
require_once('connection.php');

if(isset($_POST['submit'])){

	if(empty($_POST['name'])|| empty($_POST['mail'])||empty($_POST['age'])){
		echo "Please input valid information";
	}  else {

		$username=$_POST['name'];
		$usermail=$_POST['mail'];
		$userage=$_POST['age'];

		$query= "insert into records (User_ID, User_Name, User_Email, User_Age) values ('', '$username', '$usermail', '$userage')";
		$result= mysqli_query($mysqli,$query);

		if($result){
			header('Location:view.php');
		} else {
			echo "Please check your Query";
		}
		
	}
		

} else {
	header("Location:index.php");
}


?>